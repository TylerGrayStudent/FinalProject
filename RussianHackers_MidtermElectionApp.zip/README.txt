Run RussianHackers_MidtermElectionApp.jar.
I had to run it from the cmd line using java-jar RussianHackers_MidtermElectionApp.jar.
The other jars need to be in the same folder, as it is currently structered. 

I did have to rearrange the package files of the code to get it to work, as when the jar is created the 
urls arent the same for an FXML loader. Hopefully this runs for you as well.